All timestamps are returned in ISO 8601 format:
`YYYY-MM-DDTHH:MM:SSZ`