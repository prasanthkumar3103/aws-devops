Some useful format or example here 

OS name: "linux", version: "3.19.0-25-generic", arch: "amd64", family: "unix"