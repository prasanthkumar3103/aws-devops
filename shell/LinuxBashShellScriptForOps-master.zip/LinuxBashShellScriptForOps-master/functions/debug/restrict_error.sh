#!/usr/bin/env bash
# same as set -e, set +e
set -o errexit
set +o errexit