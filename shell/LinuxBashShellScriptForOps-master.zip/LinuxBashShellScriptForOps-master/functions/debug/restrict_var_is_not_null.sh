#!/usr/bin/env bash

set -u
# Or
set -o nounset
