# How to write a strong shell script
1.basic knowledge and best practice

2.debug your code

3.if I have seen further it is by standing on ye shoulders of Giants, such as 'grep 'keyword' -r /etc''

4.circulation and iteration