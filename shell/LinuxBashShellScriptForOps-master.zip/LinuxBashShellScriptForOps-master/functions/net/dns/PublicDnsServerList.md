# Public DNS Server List
## Public DNS Server List
### CHINATELCOM 10000 [Website](http://green.114dns.com/)
114.114.114.114; 
114.114.115.115;
### CHINANUNICOM 10010 
202.102.128.68; 
202.102.134.68;
### CMCC 10086 
211.137.191.26; 
218.201.96.130;
### AliDNS [Website](http://www.alidns.com/)
223.5.5.5; 
223.6.6.6;
### tencent [Website](https://www.dnspod.cn/Products/Public.DNS/)
119.29.29.29; 
182.254.116.116;
### baidu [Website](http://dudns.baidu.com/intro/publicdns/)
180.76.76.76;
### Google [Website](https://developers.google.com/speed/public-dns/)
8.8.8.8;
8.8.4.4;
### others  [Website](http://public-dns.info/nameserver/cn.html)
http://public-dns.info/nameserver/cn.json

## DNS over HTTP/HTTPS
https://developers.google.com/speed/public-dns/docs/dns-over-https

## useful commands
`dig www.taobao.com +short`
