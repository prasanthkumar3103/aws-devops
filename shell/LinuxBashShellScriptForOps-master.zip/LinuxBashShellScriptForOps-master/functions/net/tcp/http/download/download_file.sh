#!/usr/bin/env bash
#nohup curl -q --fail --location --max-redirs 10 --user-agent 'Vagrant/1.8.1 (+https://www.vagrantup.com; ruby2.2.3)' --continue-at - --output /root/box3c0998296d01dea7d3da811797eac21584a8b71a http://files.edx.org/vagrant-images/20151221-dogwood-fullstack-rc2.box &
#curl -q --fail --location --max-redirs 10 --user-agent 'Vagrant/1.8.1 (+https://www.vagrantup.com; ruby2.2.3)' --continue-at - --output /tmp/curl_path_to_file http://files.edx.org/vagrant-images/20151221-dogwood-fullstack-rc2.box
#wget -c <url>
# wget <url> -O /path/to/file -t 2  # set number of retries to NUMBER (0 unlimits)
# curl -LSs <url> -o /path/to/file
# curl -LOSs <url>