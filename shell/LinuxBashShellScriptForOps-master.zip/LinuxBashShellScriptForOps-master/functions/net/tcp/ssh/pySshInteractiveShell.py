#!/usr/bin/python
# encoding: utf-8
# -*- coding: utf8 -*-
"""
Created by PyCharm.
File:               LinuxBashShellScriptForOps:pySshInteractiveShell.py
User:               Guodong
Create Date:        2017/9/12
Create Time:        17:25
Description:
References:         Fabric is better for interactive shell than paramiko.
                    Run system command is better than Fabric.
                    All in all, Run system command is better than Fabric and Paramiko.
Prerequisites:      []
 """
