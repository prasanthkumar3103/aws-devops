### ssh public key fingerprint
```bash
# get ssh public's fingerprint
ssh-keygen -lf ~/.ssh/id_rsa.pub 
```