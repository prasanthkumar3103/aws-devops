#!/usr/bin/env bash
# Not all Linux distribution Operating System have sbin in PATH for regular users.
PATH=$PATH:/usr/local/sbin:/usr/sbin:/sbin
