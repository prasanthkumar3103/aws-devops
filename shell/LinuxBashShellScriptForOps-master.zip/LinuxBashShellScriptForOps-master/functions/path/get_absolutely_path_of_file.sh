#!/usr/bin/env bash

#realpath /path/to/file
#readlink -f /path/to/file
#find /path/to/file -name file
#basename - strip directory and suffix from filenames
#dirname - strip last component from file name
