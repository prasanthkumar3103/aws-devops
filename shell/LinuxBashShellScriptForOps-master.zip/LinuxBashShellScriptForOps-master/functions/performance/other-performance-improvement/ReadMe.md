# THIS DIRECTORY CONTAINS THOSE CONTENTS AS FOLLOWS
> Note: mainly for Python coding, some shell coding as well 
- performance tuning
- performances improvements
- code best practice for performance tuning
- some algorithm related
