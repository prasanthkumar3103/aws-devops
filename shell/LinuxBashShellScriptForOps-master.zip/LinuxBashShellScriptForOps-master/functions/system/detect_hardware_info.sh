#!/usr/bin/env bash
# facter
# dmidecode
# lspci