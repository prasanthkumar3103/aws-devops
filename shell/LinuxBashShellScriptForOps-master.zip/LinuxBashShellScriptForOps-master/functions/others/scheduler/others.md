# Others Implement
[Periodic Tasks With Celery](http://docs.celeryproject.org/en/latest/userguide/periodic-tasks.html)