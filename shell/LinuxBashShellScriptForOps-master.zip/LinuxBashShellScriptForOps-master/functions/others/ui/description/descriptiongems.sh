#!/usr/bin/env bash
# Progress: 0% (Rate: 106k/s, Estimated time remaining: 8:31:25)
# Estimated time remaining
# ==> default: Adding box