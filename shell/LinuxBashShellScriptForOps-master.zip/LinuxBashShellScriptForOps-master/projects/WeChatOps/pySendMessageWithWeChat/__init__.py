#!/usr/bin/python
# encoding: utf-8
# -*- coding: utf8 -*-
"""
Created by PyCharm.
File:               LinuxBashShellScriptForOps:__init__.py
User:               Guodong
Create Date:        2016/8/12
Create Time:        11:47
 """
