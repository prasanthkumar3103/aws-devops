# HappyBashForHappyLife
This repository contains some funny and usefull shell scripts writen with Bash on Linux, you can find what it can be done with them by reading its header.
