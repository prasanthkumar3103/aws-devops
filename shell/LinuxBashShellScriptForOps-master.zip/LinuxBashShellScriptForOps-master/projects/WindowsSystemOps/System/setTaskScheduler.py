#!/usr/bin/python
# encoding: utf-8
# -*- coding: utf8 -*-
"""
Created by PyCharm.
File:               LinuxBashShellScriptForOps:setTaskScheduler.py
User:               Guodong
Create Date:        2016/12/19
Create Time:        21:58
 """
