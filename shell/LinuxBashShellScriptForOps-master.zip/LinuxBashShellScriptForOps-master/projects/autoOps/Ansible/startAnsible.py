#!/usr/bin/python
# encoding: utf-8
# -*- coding: utf8 -*-
# Ansible is an IT automation tool.
# It can configure systems, deploy software, and orchestrate more advanced IT tasks
# such as continuous deployments or zero downtime rolling updates.
# [Ansible Documentation](http://docs.ansible.com/)
# [Ansible Documentation](http://docs.ansible.com/ansible/index.html)
# [Installation](http://docs.ansible.com/ansible/intro_installation.html)
# [Getting Started](http://docs.ansible.com/ansible/intro_getting_started.html)
# [Playbooks](http://docs.ansible.com/ansible/playbooks.html)
# [Inventory](http://docs.ansible.com/ansible/intro_inventory.html)
# [ansible-container](http://docs.ansible.com/ansible-container/index.html)
