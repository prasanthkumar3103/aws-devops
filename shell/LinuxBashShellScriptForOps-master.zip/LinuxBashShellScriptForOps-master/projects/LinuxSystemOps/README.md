# Linux System Ops
Linux system basic maintenance, such as 'package management', 'software management', etc.

## Package Management

## Software Management
Include some common software installation scripts here.
- nginx
- docker