This directory contains some python and bash scripts can be used to do daily ops job.

A common usage is check how does Linux system work and system running status.

With this scripts,
you do not need login to Linux system,
execute scripts or commands throw a python script(here called 'dailyOpsManage.py').

Note: debug mode is enable default on Windows system.
You can using this dailyOpsManage.py to running it directly on Windows system.
