# Linux System Services Init Script Collections
Linux services scripts, we can learn how to write good code from system scripts

## SysV
[System V](https://en.wikipedia.org/wiki/System_V_Interface_Definition)
