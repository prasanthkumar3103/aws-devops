#!/usr/bin/python
# encoding: utf-8
# -*- coding: utf8 -*-
"""
Created by PyCharm.
File:               LinuxBashShellScriptForOps:BackupMysql.py
User:               Guodong
Create Date:        2016/11/16
Create Time:        10:28
 """

# TODO(GuodongDing) Using Python to backup mysql database is not a pythonic way because of
# using the system command mysqldump and xtrabackup is inevitable.
