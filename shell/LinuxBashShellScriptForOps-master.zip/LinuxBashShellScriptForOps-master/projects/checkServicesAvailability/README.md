# About this directory

using python or bash shell to check some services' availability.

such as:

    check http services
    check others services