# About this testNoHttpResponseException.py

using this script to test some websites' availability.

You can add more than 1 host, please search "hosts" to change the setting.
such as:
```
hosts = ['https://webpush.wx.qq.com/cgi-bin/mmwebwx-bin/synccheck']
```

or


```
hosts = ['https://webpush.wx.qq.com/cgi-bin/mmwebwx-bin/synccheck',
'https://webpush.wx2.qq.com/cgi-bin/mmwebwx-bin/synccheck', 'more hosts...']
```