# General Coding Standards
> http://diamond.readthedocs.io/en/latest/Development/Coding-Standards/
- Unit tests are highly recommended
- PEP-8
- Documentation should be done docstr style at the start of the collector. This is how we generate the wiki
- The use of positional arguments for functions is strongly discouraged.

